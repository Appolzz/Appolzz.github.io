function myFunc() {
            document.body.style.backgroundColor = "green";
        }